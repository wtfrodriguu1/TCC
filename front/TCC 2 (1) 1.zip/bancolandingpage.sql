create database db_tasks;

use db_tasks;

create table task(
	id int auto_increment primary key,
    email varchar(45) not null,
    senha varchar(30) not null
);
 select * from task;
 
 drop database db_tasks;
 